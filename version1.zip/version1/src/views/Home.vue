<!--
 * @Description: 首页组件
 * @Author: hai-27
 * @Date: 2020-02-07 16:23:00
 * @LastEditors: hai-27
 * @LastEditTime: 2020-02-27 13:36:12
 -->
 <template>
   
    <!-- 轮播图 -->
    <div class="block">
      <el-carousel height="460px">
        <el-carousel-item v-for="item in carousel" :key="item.carousel_id">
          <img style="height:460px;" :src="'data:image/png;base64,' + item.imgPath" :alt="item.describes" />
          
        </el-carousel-item>
      </el-carousel>
    </div>
</template>
<script>
export default {
  data() {
    return {
      carousel: "", // 轮播图数据
    };
  },
  watch: {
   
  },
  created() {
    // 获取轮播图数据
    this.$axios
      .post('/onlineshop-product/carousel/carousel/get', {})
      .then(res => {
        this.carousel=res.data
      
      })
      .catch(err => {
        return Promise.reject(err);
      });
  }
};
</script>
<style scoped>
@import "../assets/css/index.css";
</style>