package springboot.version.orders.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author jobob
 * @since 2022-12-03
 */
@RestController
@RequestMapping("/orders/orders")
public class OrdersController {

}
