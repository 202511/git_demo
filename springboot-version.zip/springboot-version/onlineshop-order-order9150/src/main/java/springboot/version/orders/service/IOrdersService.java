package springboot.version.orders.service;

import org.springframework.stereotype.Service;
import springboot.version.orders.entity.Orders;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author jobob
 * @since 2022-12-03
 */
@Service
public interface IOrdersService extends IService<Orders> {

}
