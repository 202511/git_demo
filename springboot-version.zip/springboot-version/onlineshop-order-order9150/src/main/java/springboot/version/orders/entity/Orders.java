package springboot.version.orders.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.TableId;
import java.time.LocalDateTime;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.springframework.stereotype.Component;

/**
 * <p>
 * 
 * </p>
 *
 * @author jobob
 * @since 2022-12-03
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("ORDERS")
@Component
public class Orders implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId("ID")
    private Double id;

    @TableField("ORDER_ID")
    private LocalDateTime orderId;

    @TableField("USER_ID")
    private Double userId;

    @TableField("PRODUCT_ID")
    private Double productId;

    @TableField("PRODUCT_NUM")
    private Double productNum;

    @TableField("PRODUCT_PRICE")
    private byte[] productPrice;

    @TableField("ORDER_TIME")
    private LocalDateTime orderTime;


}
