package springboot.version;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Order9150 {
    public static void main(String[] args) {
        SpringApplication.run(Order9150.class, args);
    }
}
