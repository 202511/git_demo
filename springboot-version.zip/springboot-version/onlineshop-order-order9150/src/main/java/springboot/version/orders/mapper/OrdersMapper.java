package springboot.version.orders.mapper;

import org.apache.ibatis.annotations.Mapper;
import springboot.version.orders.entity.Orders;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author jobob
 * @since 2022-12-03
 */
@Mapper
public interface OrdersMapper extends BaseMapper<Orders> {

}
