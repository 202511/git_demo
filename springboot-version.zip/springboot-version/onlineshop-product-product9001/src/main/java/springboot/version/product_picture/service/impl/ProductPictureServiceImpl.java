package springboot.version.product_picture.service.impl;

import springboot.version.product_picture.entity.ProductPicture;
import springboot.version.product_picture.mapper.ProductPictureMapper;
import springboot.version.product_picture.service.IProductPictureService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author jobob
 * @since 2022-12-03
 */
@Service
public class ProductPictureServiceImpl extends ServiceImpl<ProductPictureMapper, ProductPicture> implements IProductPictureService {

}
