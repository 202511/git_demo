package springboot.version.category.entity;

import com.baomidou.mybatisplus.annotation.*;

import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.springframework.stereotype.Component;

/**
 * <p>
 * 
 * </p>
 *
 * @author jobob
 * @since 2022-12-03
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("CATEGORY")
@Component
@KeySequence(value="SEQ_ category",clazz=Integer.class)
public class Category implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "CATEGORY_ID",type = IdType.INPUT)
    private int categoryId;

    @TableField("CATEGORY_NAME")
    private String categoryName;


}
