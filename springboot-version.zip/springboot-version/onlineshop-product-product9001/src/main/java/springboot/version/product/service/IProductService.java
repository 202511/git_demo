package springboot.version.product.service;

import org.springframework.stereotype.Service;
import springboot.version.product.entity.Product;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author jobob
 * @since 2022-12-03
 */
@Service
public interface IProductService extends IService<Product> {

}
