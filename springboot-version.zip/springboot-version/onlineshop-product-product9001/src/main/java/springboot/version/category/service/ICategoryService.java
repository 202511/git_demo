package springboot.version.category.service;

import org.springframework.stereotype.Service;
import springboot.version.category.entity.Category;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author jobob
 * @since 2022-12-03
 */
@Service
public interface ICategoryService extends IService<Category> {

}
