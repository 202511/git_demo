package springboot.version.carousel.service;

import org.springframework.stereotype.Service;
import springboot.version.carousel.entity.Carousel;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author jobob
 * @since 2022-12-04
 */
@Service
public interface ICarouselService extends IService<Carousel> {

}
