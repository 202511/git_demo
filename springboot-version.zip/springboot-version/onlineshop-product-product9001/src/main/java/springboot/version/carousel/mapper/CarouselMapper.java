package springboot.version.carousel.mapper;

import org.apache.ibatis.annotations.Mapper;
import springboot.version.carousel.entity.Carousel;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author jobob
 * @since 2022-12-04
 */
@Mapper
public interface CarouselMapper extends BaseMapper<Carousel> {

}
