package springboot.version;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Product9001 {
    public static void main(String[] args) {
        SpringApplication.run(Product9001.class, args);
    }
}
