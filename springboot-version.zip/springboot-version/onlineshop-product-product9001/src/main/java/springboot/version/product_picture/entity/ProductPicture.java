package springboot.version.product_picture.entity;

import com.baomidou.mybatisplus.annotation.*;

import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import oracle.sql.BLOB;
import org.springframework.stereotype.Component;

/**
 * <p>
 * 
 * </p>
 *
 * @author jobob
 * @since 2022-12-03
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("PRODUCT_PICTURE")
@Component
@KeySequence(value="SEQ_PRODUCT_PICTURE",clazz=Integer.class)
public class ProductPicture implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "ID", type = IdType.INPUT)
    private int id;

    @TableField("PRODUCT_ID")
    private int productId;

    @TableField("PRODUCT_PICTURE")
    private byte[] productPicture;


}
