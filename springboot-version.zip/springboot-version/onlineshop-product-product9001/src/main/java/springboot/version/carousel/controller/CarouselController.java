package springboot.version.carousel.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import io.netty.handler.codec.base64.Base64Encoder;
import oracle.jdbc.proxy.annotation.Post;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;
import springboot.version.carousel.entity.Carousel;
import springboot.version.carousel.service.ICarouselService;
import springboot.version.product_picture.entity.ProductPicture;
import springboot.version.product_picture.service.IProductPictureService;

import javax.annotation.Resource;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Base64;
import java.util.Collection;
import java.util.Map;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author jobob
 * @since 2022-12-04
 */
@RestController
@RequestMapping("/carousel/carousel")
public class CarouselController {
    @Resource
    ICarouselService iCarouselService;
    @GetMapping("/add")
    public String addPicture() throws IOException {

        String[] s={"book.png","huawei.png","phone.png","sing.png","station.png"};
        for(String t: s)
        {
            String s1 = "/carousel/" + t;
            Carousel carousel1 = new Carousel();
            carousel1.setImgpath(s1);
            carousel1.setDescribes("好好好");
            iCarouselService.save(carousel1);
        }


        return "添加成功";
    }
    @PostMapping("/get")
    public Carousel[] getPicture()
    {
        Carousel[] carousels = new Carousel[4];
        for(int i=6;i<=9;i++)
        {
            Carousel byId = iCarouselService.getById(i);
            carousels[i-6]=byId;
        }
        return  carousels;
    }



}
