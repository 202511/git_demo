package springboot.version.product_picture.controller;


import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;
import springboot.version.product.entity.Product;
import springboot.version.product.service.IProductService;
import springboot.version.product_picture.entity.ProductPicture;
import springboot.version.product_picture.service.IProductPictureService;

import javax.annotation.Resource;
import java.io.*;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author jobob
 * @since 2022-12-03
 */
@RestController
@RequestMapping("/product_picture/product-picture")
public class ProductPictureController {
     @Resource
    IProductPictureService iProductPictureService;
     @GetMapping("/add")
    public String addPicture() throws IOException {
         File file = new File("C:\\Users\\86136\\Desktop\\springboot-version\\onlineshop-product-product9001\\src\\main\\resources\\static\\phone.png");
         FileInputStream fileInputStream = new FileInputStream(file);
         byte[] bytes = new byte[(int)file.length()];
         fileInputStream.read(bytes);
         fileInputStream.close();
         ProductPicture productPicture = new ProductPicture();
         productPicture.setProductPicture(bytes);
         iProductPictureService.save(productPicture);


         return "添加成功";
     }
}
