package springboot.version.carousel.entity;

import com.baomidou.mybatisplus.annotation.*;

import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.springframework.stereotype.Component;

/**
 * <p>
 * 
 * </p>
 *
 * @author jobob
 * @since 2022-12-04
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("CAROUSEL")
@Component
@KeySequence(value="SEQ_carousel",clazz=Integer.class)
public class Carousel implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "CAROUSEL_ID", type = IdType.INPUT)
    private int carouselId;

    @TableField("IMGPATH")

    private String imgpath;

    @TableField("DESCRIBES")
    private String describes;


}
