package springboot.version.product.entity;

import com.baomidou.mybatisplus.annotation.*;

import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.springframework.stereotype.Component;

/**
 * <p>
 * 
 * </p>
 *
 * @author jobob
 * @since 2022-12-03
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("PRODUCT")
@Component
@KeySequence(value="SEQ_product",clazz=Integer.class)
public class Product implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "PRODUCT_ID",type = IdType.INPUT)
    private int productId;

    @TableField("PRODUCT_NAME")
    private String productName;

    @TableField("CATEGORY_ID")
    private int categoryId;

    @TableField("PRODUCT_TITLE")
    private String productTitle;

    @TableField("PRODUCT_INTRO")
    private String productIntro;

    @TableField("PRODUCT_PICTURE")
    private String productPicture;

    @TableField("PRODUCT_SELLING_PRICE")
    private double productSellingPrice;

    @TableField("PRODUCT_NUM")
    private int productNum;

    @TableField("PRODUCT_SALES")
    private int productSales;


}
