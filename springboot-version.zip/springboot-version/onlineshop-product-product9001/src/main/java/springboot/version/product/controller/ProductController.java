package springboot.version.product.controller;


import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;
import springboot.version.product.entity.Product;
import springboot.version.product.service.IProductService;

import javax.annotation.Resource;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author jobob
 * @since 2022-12-03
 */
@RestController
@RequestMapping("/product/product")
public class ProductController {
       @Resource
       IProductService iProductService;
       @GetMapping("/add")
       public String addProduct()
       {
              String s = "/onlineshop-product";
              Product product = new Product();
              product.setProductName("iphone-x");
              product.setProductPicture(s+"/iphone-x.jpg");
              product.setProductSellingPrice(9900.0);
              product.setCategoryId(1);
              product.setProductTitle("title");
              product.setProductIntro("A11处理器/120盒Hz屏幕刷新率/5.8英寸视网膜XDR显示屏/2716mAh支持快速充电/\n" +
                      "后置1200万像素/人脸识别/多功能NFC");
              iProductService.save(product);
              return "添加成功";
       }
       @PostMapping("/get")
       public Product[] getProduct()
       {
              Product[] products = new Product[3];
              for(int i=2;i<=4;i++)
              {
                     Product byId = iProductService.getById(i);
                     products[i-2]=byId;

              }
              return products;
       }

}
