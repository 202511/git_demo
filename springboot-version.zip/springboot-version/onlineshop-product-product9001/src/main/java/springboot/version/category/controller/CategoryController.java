package springboot.version.category.controller;


import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;
import springboot.version.category.entity.Category;
import springboot.version.category.service.ICategoryService;

import javax.annotation.Resource;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author jobob
 * @since 2022-12-03
 */
@RestController
@RequestMapping("/category/category")
public class CategoryController {
    @Resource
    ICategoryService iCategoryService;
    @PostMapping("/get")
    public Category[] getCategory()
    {
        Category[] categories = new Category[5];
        for(int i=1;i<=5;i++)
        {
            Category byId = iCategoryService.getById(i);
            categories[i-1]=byId;
        }
        return categories;
    }


}
