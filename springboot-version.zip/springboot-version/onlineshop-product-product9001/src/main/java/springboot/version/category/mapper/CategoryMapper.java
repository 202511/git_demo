package springboot.version.category.mapper;

import org.apache.ibatis.annotations.Mapper;
import springboot.version.category.entity.Category;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author jobob
 * @since 2022-12-03
 */
@Mapper
public interface CategoryMapper extends BaseMapper<Category> {

}
