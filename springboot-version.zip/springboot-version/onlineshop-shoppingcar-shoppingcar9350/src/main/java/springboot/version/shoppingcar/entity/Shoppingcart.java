package springboot.version.shoppingcar.entity;

import com.baomidou.mybatisplus.annotation.*;

import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Value;
import lombok.experimental.Accessors;

/**
 * <p>
 * 
 * </p>
 *
 * @author jobob
 * @since 2022-12-03
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("SHOPPINGCART")
@KeySequence(value="SEQ_ category",clazz=Integer.class)
public class Shoppingcart implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "ID",type = IdType.INPUT)
    private int id;

    @TableField("USER_ID")
    private int userId;

    @TableField("PRODUCT_ID")
    private int productId;

    @TableField("NUM")
    private int num;


}
