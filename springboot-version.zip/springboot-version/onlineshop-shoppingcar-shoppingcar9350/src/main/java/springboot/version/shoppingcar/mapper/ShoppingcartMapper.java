package springboot.version.shoppingcar.mapper;

import springboot.version.shoppingcar.entity.Shoppingcart;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author jobob
 * @since 2022-12-03
 */
public interface ShoppingcartMapper extends BaseMapper<Shoppingcart> {

}
