package springboot.version.shoppingcar.service;

import springboot.version.shoppingcar.entity.Shoppingcart;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author jobob
 * @since 2022-12-03
 */
public interface IShoppingcartService extends IService<Shoppingcart> {

}
