package springboot.version;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShoppingCar9350 {
    public static void main(String[] args) {
        SpringApplication.run(ShoppingCar9350.class, args);
    }
}
