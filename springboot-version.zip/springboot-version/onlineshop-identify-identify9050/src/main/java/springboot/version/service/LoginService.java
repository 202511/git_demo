package springboot.version.service;

import org.apache.catalina.User;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.*;
import springboot.version.entity.Result;
import springboot.version.entity.Users;

@Component
//这里的value 指的是nacos上的服务名
@FeignClient(value = "onlineshop-user")
public interface LoginService {

    @PostMapping("/users/users/login")
    public Result login(@RequestBody Users users);


}
