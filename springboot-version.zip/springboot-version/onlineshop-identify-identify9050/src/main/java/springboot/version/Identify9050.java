package springboot.version;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

@EnableFeignClients
@SpringBootApplication
public class Identify9050 {
    public static void main(String[] args) {
        SpringApplication.run(Identify9050.class, args);
    }
}
