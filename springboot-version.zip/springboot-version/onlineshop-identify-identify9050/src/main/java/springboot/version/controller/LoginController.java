package springboot.version.controller;


import org.springframework.aop.scope.ScopedProxyUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import springboot.version.entity.Result;
import springboot.version.entity.Users;
import springboot.version.service.LoginService;

import javax.annotation.Resource;

@RestController
public class LoginController {
    @Resource
    LoginService loginService;
    @PostMapping("/identify/login")
    public Result login(@RequestBody Users users)
    {
        System.out.println(users);
        Result login = loginService.login(users);
        return login;
    }
}
