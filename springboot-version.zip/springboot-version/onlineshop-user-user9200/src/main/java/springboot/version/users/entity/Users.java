package springboot.version.users.entity;

import com.baomidou.mybatisplus.annotation.*;

import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.springframework.stereotype.Component;

/**
 * <p>
 * 
 * </p>
 *
 * @author jobob
 * @since 2022-12-03
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("USERS")
@Component
@KeySequence(value="SEQ_USERS",clazz=Integer.class)
public class Users implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "USER_ID",type = IdType.INPUT)
    private int userId;

    @TableField("USERNAME")
    private String username;

    @TableField("PASSWORD")
    private String password;

    @TableField("USERPHONENUMBER")
    private String userphonenumber;


}
