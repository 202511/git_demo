package springboot.version.users.service;

import org.springframework.stereotype.Service;
import springboot.version.users.entity.Users;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author jobob
 * @since 2022-12-03
 */
@Service
public interface IUsersService extends IService<Users> {

}
