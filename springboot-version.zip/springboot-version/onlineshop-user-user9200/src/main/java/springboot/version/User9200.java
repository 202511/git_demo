package springboot.version;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class User9200 {
    public static void main(String[] args) {
        SpringApplication.run(User9200.class, args);
    }
}
