package springboot.version.users.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import org.springframework.boot.autoconfigure.security.SecurityProperties;
import org.springframework.web.bind.annotation.*;

import springboot.version.users.entity.Result;
import springboot.version.users.entity.Users;
import springboot.version.users.service.IUsersService;

import javax.annotation.Resource;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author jobob
 * @since 2022-12-03
 */
@RestController
@RequestMapping("/users/users")
public class UsersController {
    @Resource
    IUsersService iUsersService;

    @RequestMapping(value = "/add" , method = RequestMethod.POST)
    public String addUser(@RequestBody Users users)
    {
        System.out.println(users);

//        System.out.println(s);
//        users.setUsername(s[0]);
//        users.setPassword(s[1]);
        iUsersService.save(users);
        return "001";
    }
    @PostMapping("/get")
    public String getU(@RequestBody  Users users)
    {
        System.out.println(users.getUsername());
      String  username=users.getUsername();
        QueryWrapper queryWrapper = new QueryWrapper();
        queryWrapper.eq("USERNAME",username);
        Users one = iUsersService.getOne(queryWrapper);
        if(one== null)
        {
            return "001";
        }
        else
        {
            return "020";
        }
    }
    @PostMapping("/login")
    public Result login(@RequestBody Users users)
    {
        System.out.println(users);
        QueryWrapper queryWrapper = new QueryWrapper();
        queryWrapper.eq("username", users.getUsername());
        queryWrapper.eq("password", users.getPassword());
        Users one = iUsersService.getOne(queryWrapper);
        Result result = new Result();
        if(one== null )
        {
            result.setCode("222");
            return result;
        }
        else
        {
            result.setUser(users);
            result.setCode("001");
            result.setMsg("登录成功");
            return result;

        }

    }

}
