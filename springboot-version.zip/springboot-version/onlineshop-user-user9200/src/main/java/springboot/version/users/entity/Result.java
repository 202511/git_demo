package springboot.version.users.entity;

import lombok.Data;
import org.springframework.stereotype.Component;

@Data
@Component
public class Result {
    Users user;
    String msg;
    String code;
}
